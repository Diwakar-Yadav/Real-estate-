// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCOpx2ORb07bDnYZ1_QF_UfpLqMKMlLvy4",
  authDomain: "realestate-c7c6d.firebaseapp.com",
  projectId: "realestate-c7c6d",
  storageBucket: "realestate-c7c6d.appspot.com",
  messagingSenderId: "423579352324",
  appId: "1:423579352324:web:2229611eecd0dc1324a451"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);